﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UBIT.sqldataProject1.ClassHelper
{
    public class EnrollmentHelper
    {
        public Enrollment GetEnrollment(string StudentSeatNo, int TermId, int SubjectId)
        {
            var db = new IPTEntities1();

            var temp = db.Enrollments.Where(e => e.StudentSeatNo == StudentSeatNo && e.TermId == TermId && e.SubjectId == SubjectId).First();

            return temp;
        }

        public List<Enrollment> GetEnrollments(int termId, int subjectId)
        {
            var db = new IPTEntities1();

            var temp = db.Enrollments.Where(e =>  e.TermId == termId && e.SubjectId == subjectId).ToList();

            return temp;
        }

    }


}
